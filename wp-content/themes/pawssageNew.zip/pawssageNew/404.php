<?php get_header(); ?>
	<div class="main-content">
  <div class="container">
    <div class="col-md-12">
      <div class="row">
        <div class="col-md-9">
     
	<h2>Error 404 - Page Not Found</h2>
	                    
                      

        </div><!--col-md-9-->
        

			<?php get_sidebar(); ?>
      </div><!--row contains whole main content-->
	  
    </div><!--col-md-12 placed to adjust the row margin-->
  </div><!--container-->
</div><!--main content--> 


<?php get_footer(); ?>