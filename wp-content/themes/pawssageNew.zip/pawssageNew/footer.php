 


      <footer>
        <div class="container">
          <div class="row-fluid">
<div id="footer-widgets" class="full-container">
		<?php dynamic_sidebar( 'sidebar-footer' ) ?>
	</div><!-- #footer-widgets -->
          </div> <!--row-->   
       </div><!--container-->
<?php wp_footer(); ?>       
</body>
</html>
